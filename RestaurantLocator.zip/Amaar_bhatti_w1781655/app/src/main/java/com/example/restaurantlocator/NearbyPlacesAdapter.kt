package com.example.restaurantlocator

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class NearbyPlacesAdapter(private val nearbyRestaurantList: List<Restaurant>) :
    RecyclerView.Adapter<NearbyPlacesAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.nearby_restaurant_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val nearbyRestaurant = nearbyRestaurantList[position]
        //Links the data from the data class to the textview id
        holder.name.text = nearbyRestaurant.name
        holder.address.text = nearbyRestaurant.address
        holder.rating.text = "Rating: ${nearbyRestaurant.rating}"
        holder.latlng.text = "${nearbyRestaurant.latLng}"

    }

    override fun getItemCount(): Int {
        return nearbyRestaurantList.size
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        //calls Textview widget from nearby_restaurant_item layout file
        val name: TextView = view.findViewById(R.id.place_name)
        val address: TextView = view.findViewById(R.id.place_address)
        val latlng: TextView = view.findViewById(R.id.place_latlng)
        val rating: TextView = view.findViewById(R.id.place_rating)
    }
}





