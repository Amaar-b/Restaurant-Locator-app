package com.example.restaurantlocator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest
import com.google.android.libraries.places.api.net.PlacesClient
import org.json.JSONObject
import java.net.URL


class RestaurantActivity : AppCompatActivity() {

    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var placesClient: PlacesClient
    lateinit var restaurantList: RecyclerView
    private val RequestLocationPermission = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurant)

        // Calls listOfRestaurant function
        listOfRestaurant()

        getLocation()

        var mapbt = findViewById<Button>(R.id.map)
        var homebt = findViewById<Button>(R.id.home)
        var refreshbt = findViewById<Button>(R.id.refresh)


        restaurantList = findViewById(R.id.recyclerView)
        val layoutManager = LinearLayoutManager(this)
        restaurantList.layoutManager = layoutManager

        homebt.setOnClickListener {
            listOfRestaurant()
        }

        mapbt.setOnClickListener {
            //Links to the map page
            val new = Intent(this, MapActivity::class.java)
            //Start the Map Activity
            startActivity(new)
        }

        refreshbt.setOnClickListener {
            listOfRestaurant()
        }
    }

    fun listOfRestaurant(){

        //Initialising the Place SDK
        Places.initialize(applicationContext, getString(R.string.API_KEY))
        placesClient = Places.createClient(this)

        // Initialize the Fused Location Provider Client
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        //Permission check
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
            Toast.makeText(this, "Location denied", Toast.LENGTH_SHORT).show()
        }

        // A list of fields that will be retrieve from the API
        val placeFields = listOf(Place.Field.NAME, Place.Field.ADDRESS,
            Place.Field.LAT_LNG, Place.Field.RATING, Place.Field.TYPES)

        // Builds a FindCurrentPlaceRequest using the chosen fields
        val requests = FindCurrentPlaceRequest.builder(placeFields).build()

        // Runs the request and handle the response using the callback method
        placesClient.findCurrentPlace(requests).addOnSuccessListener { response ->
            // retrieves the list of place likelihoods from the response
            val placesList = response.placeLikelihoods

            Log.d("App - ", "Total number of places found: ${placesList.size}")

            //An empty list to store all nearby Restaurants detail
            val nearbyRestaurantList = mutableListOf<Restaurant>()

            // Loop through the list of place likelihoods
            for (placeLikelihood in placesList) {
                // retrieves the Place object from the place likelihood
                val places = placeLikelihood.place

                Log.d("App - ", "Place ${places.name} - types: ${places.types}")

                //Checks if the places are Restaurants, Cafe and Pubs
                if (places.types != null && (places.types.contains(Place.Type.RESTAURANT)
                            || places.types.contains(Place.Type.CAFE) || places.types.contains(Place.Type.BAR))) {
                    nearbyRestaurantList.add(Restaurant(places.name, places.address, places.latLng, places.rating))
                }
            }


            val restaurantAdapter = NearbyPlacesAdapter(nearbyRestaurantList)
            // Set the adapter to the RecyclerView to display the list of restaurants near the user location
            restaurantList.adapter = restaurantAdapter




//            val sb = StringBuilder()
//            for (restaurant in nearbyRestaurantList) {
//                sb.append(restaurant.name)
//                sb.append("\n")
//                sb.append(restaurant.address)
//                sb.append("\n")
//                sb.append("Latitude: ${restaurant.latLng?.latitude}, Longitude: ${restaurant.latLng?.longitude}")
//                sb.append("\n\n")
//            }
//
//            tv.text = sb.toString()
        }

    }

    fun getLocation() {
        // Check if the app has permission to access location
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is granted, the location functionality will start

        } else {
            // If permission is not granted, request the location permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                RequestLocationPermission
            )
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == RequestLocationPermission) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // If permission granted, proceed with location functionality

            } else {
                // if the permission is denied, display a toast message and disable location functionality
                Toast.makeText(
                    this,
                    "Location permission denied",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }
}