package com.example.restaurantlocator

import android.Manifest
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient

class MapActivity : AppCompatActivity() {

    lateinit var fusedLocationClient: FusedLocationProviderClient
    lateinit var placesClient: PlacesClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        var homebt = findViewById<Button>(R.id.homebtt)
        var mapbt = findViewById<Button>(R.id.mapbtt)

        homebt.setOnClickListener {
            //Linked to the Restaurant activity page (Home page)
            val new = Intent(this, RestaurantActivity::class.java)
            //Starts the Home page
            startActivity(new)
        }

        mapbt.setOnClickListener {
            val new = Intent(this, MapActivity::class.java)
            startActivity(new)
        }

        val mapFragment = MapFragment()
        supportFragmentManager.beginTransaction()
            .replace(R.id.googlemap, mapFragment)
            .commit()

        //Initialising the Place SDK
        Places.initialize(applicationContext, getString(R.string.API_KEY))
        placesClient = Places.createClient(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

    }


}