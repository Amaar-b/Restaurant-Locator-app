package com.example.restaurantlocator

import android.content.pm.PackageManager
import androidx.fragment.app.Fragment

import android.Manifest
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat

import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest
import com.google.android.libraries.places.api.net.PlacesClient


class MapFragment : Fragment(), OnMapReadyCallback {

    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    private lateinit var placesClient: PlacesClient
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ):
            View? {
        val view = inflater.inflate(R.layout.fragment_map, container, false)

        // Initialize the Places API client
        Places.initialize(requireContext().applicationContext, getString(R.string.API_KEY))
        placesClient = Places.createClient(requireContext())

        mapView = view.findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)

        return view

    }

    override fun onResume() {
        super.onResume()
        //Resume the mapView object
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        //Pauses the mapView object
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        //Destroy the mapView object
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        //Release any unused resources associated with the MapView object
        mapView.onLowMemory()
    }

    override fun onMapReady(googlemap: GoogleMap) {
        googleMap = googlemap

        //Location Permission check
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return

        }
        //Add the zoom control onto the map
        googleMap.uiSettings.isZoomControlsEnabled = true

        //Displays the user current location on the map
        googleMap.isMyLocationEnabled = true

        // Gets the user's last known location
        val fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(requireContext())
        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latLng = LatLng(location.latitude, location.longitude)

                // Move the camera angle to the user's location
                googleMap.moveCamera(
                    CameraUpdateFactory.newLatLngZoom(latLng, 15f)
                )

                // Searches for nearby restaurants
                val request = FindCurrentPlaceRequest.newInstance(
                    listOf(Place.Field.NAME, Place.Field.LAT_LNG,
                        Place.Field.TYPES)
                )
                placesClient.findCurrentPlace(request).addOnSuccessListener { response ->
                    for (placeLikelihood in response.placeLikelihoods) {
                        // Get the Place object for the likely place
                        val places = placeLikelihood.place
                        // Check if the places has the restaurant type
                        if (places.types != null && places.types.contains(Place.Type.RESTAURANT)
                            || places.types.contains(Place.Type.CAFE)
                            || places.types.contains(Place.Type.BAR)) {
                            // Adds a marker to the map for each restaurant nearby
                            googleMap.addMarker(
                                MarkerOptions()
                                    .position(places.latLng!!)
                                    .title(places.name)

                            )
                            // Add a circle overlay to the map with a radius of 200 meters around the user
                            googleMap.addCircle(
                                CircleOptions()
                                    .center(latLng)
                                    .radius(200.0)
                                    .strokeWidth(0f)
                                    .fillColor(Color.parseColor("#20FFC0CB"))
                            )
                        }
                    }
                }
            }
        }
    }
}
