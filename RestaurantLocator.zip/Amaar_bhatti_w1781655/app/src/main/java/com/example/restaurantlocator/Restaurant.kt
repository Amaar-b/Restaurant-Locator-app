package com.example.restaurantlocator

import com.google.android.gms.maps.model.LatLng

data class Restaurant (

    val name: String,
    val address: String,
    val latLng: LatLng,
    val rating: Double
        )