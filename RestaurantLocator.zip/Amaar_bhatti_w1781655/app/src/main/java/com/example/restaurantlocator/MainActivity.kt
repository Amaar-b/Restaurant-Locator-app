package com.example.restaurantlocator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.PopupWindow
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val RequestLocationPermission = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Links the buttons to a variable, to set a functionality to the buttons
        var startbt = findViewById<Button>(R.id.start)
        var infobt = findViewById<Button>(R.id.info)

        getLocation()

        startbt.setOnClickListener {
            //Link to the Restaurant Activity
            val new = Intent(this, RestaurantActivity::class.java)
            //Starting the Restaurant Activity
            startActivity(new)
        }

        infobt.setOnClickListener {
            popup()
        }

    }

    fun popup(){
        //this is a link to the 'about' xml layout
        var popupView = layoutInflater.inflate(R.layout.info, null)
        var popupwindow = PopupWindow(this)
        popupwindow.contentView = popupView
        //Setting the popUp view text positioning
        popupwindow.showAtLocation(popupView, Gravity.CENTER, 0, 110)

        //When the user click the pop message, the message will disappear
        popupView.setOnClickListener{
            popupwindow.dismiss()
        }
    }

    fun getLocation() {
        // Check if the app has permission to access location
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            // if permission is granted, the location functionality will start

        } else {
            // If permission is not granted, request the location permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                RequestLocationPermission
            )
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == RequestLocationPermission) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, starts the location functionality

            } else {
                // if the permission is denied, display a toast message and disable location functionality
                Toast.makeText(
                    this,
                    "Location permission denied",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }
}
